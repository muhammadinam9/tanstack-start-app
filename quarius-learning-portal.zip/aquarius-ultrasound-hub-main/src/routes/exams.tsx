import { createFileRoute } from "@tanstack/react-router";
import { Timer, Lock, PlayCircle, ChevronRight } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/exams")({
  head: () => ({
    meta: [
      { title: "Exams · Aquarius Institute" },
      { name: "description", content: "Timed exams and quizzes for sonography and MRI students." },
    ],
  }),
  component: Exams,
});

const exams = [
  { course: "MRI 305", title: "Midterm: MRI Physics", date: "Fri · May 22 · 10:00 AM", duration: "90 min", questions: 60, status: "scheduled" },
  { course: "DMS 210", title: "Quiz 4: Abdominal Pathology", date: "Available now", duration: "30 min", questions: 20, status: "available" },
  { course: "DMS 220", title: "Quiz 3: Carotid Doppler", date: "Available now", duration: "25 min", questions: 15, status: "available" },
  { course: "MRI 410", title: "Practical: Brain Anatomy Identification", date: "Tue · May 26 · 1:00 PM", duration: "60 min", questions: 40, status: "scheduled" },
  { course: "DMS 110", title: "Final: Introduction to Sonography", date: "June 8 · 9:00 AM", duration: "120 min", questions: 80, status: "locked" },
];

function StatusPill({ status }: { status: string }) {
  const map = {
    available: { c: "bg-accent text-accent-foreground", t: "Start now", i: PlayCircle },
    scheduled: { c: "bg-secondary text-secondary-foreground", t: "Scheduled", i: Timer },
    locked: { c: "bg-muted text-muted-foreground", t: "Locked", i: Lock },
  }[status]!;
  const Icon = map.i;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${map.c}`}>
      <Icon className="h-3.5 w-3.5" /> {map.t}
    </span>
  );
}

function Exams() {
  return (
    <div className="space-y-12">
      <header className="max-w-3xl">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Assessments</div>
        <h1 className="mt-3 font-serif text-5xl md:text-6xl">Exams & Quizzes</h1>
        <p className="mt-4 text-muted-foreground">
          Online proctored exams with auto-graded multiple choice and instructor-graded short answer sections.
        </p>
      </header>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          { label: "Avg. midterm score", value: "84%" },
          { label: "Exams this term", value: "12" },
          { label: "Practical hours", value: "240" },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-border/60 bg-card p-6">
            <div className="font-serif text-4xl">{s.value}</div>
            <div className="mt-1 text-xs uppercase tracking-[0.15em] text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="space-y-3">
        {exams.map((e) => (
          <div
            key={e.title}
            className="group flex flex-wrap items-center gap-6 rounded-2xl border border-border/60 bg-card p-5 transition hover:ring-soft cursor-pointer"
            onClick={() => {
              if (e.status === "available") toast.success(`Starting: ${e.title}`, { description: `${e.duration} · ${e.questions} questions` });
              else if (e.status === "scheduled") toast.info(`Scheduled: ${e.title}`, { description: e.date });
              else toast.warning(`${e.title} is locked`, { description: "This exam is not yet available." });
            }}
          >
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium uppercase tracking-[0.18em] text-accent">{e.course}</div>
              <h3 className="mt-1 font-serif text-2xl">{e.title}</h3>
              <div className="mt-1 text-xs text-muted-foreground">
                {e.date} · {e.duration} · {e.questions} questions
              </div>
            </div>
            <StatusPill status={e.status} />
            <button className="grid h-9 w-9 place-items-center rounded-full bg-secondary text-foreground transition group-hover:bg-primary group-hover:text-primary-foreground">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        ))}
      </section>

      <section className="rounded-3xl border border-border/60 bg-primary px-8 py-12 text-primary-foreground md:px-14">
        <div className="grid gap-8 md:grid-cols-[2fr_1fr] md:items-center">
          <div>
            <h2 className="font-serif text-4xl">Academic integrity matters.</h2>
            <p className="mt-3 max-w-xl text-primary-foreground/80">
              All online exams use browser lockdown and randomized question pools. Practical exams are conducted in our imaging lab under faculty supervision.
            </p>
          </div>
          <div className="rounded-2xl border border-primary-foreground/20 bg-primary-foreground/10 p-6 text-sm">
            <div className="text-xs uppercase tracking-[0.18em] text-primary-foreground/60">Need an accommodation?</div>
            <p className="mt-2">Contact Dr. Inam at least 7 days before your scheduled exam.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
