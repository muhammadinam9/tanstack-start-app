import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, ClipboardList, GraduationCap, Activity, ArrowUpRight, Calendar, Clock } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · Aquarius Institute Learning Portal" },
      { name: "description", content: "Your home base for ultrasound and MRI coursework — assignments, exams, study guides and grades." },
    ],
  }),
  component: Dashboard,
});

const upcoming = [
  { type: "Homework", title: "Abdominal Sonography — Case Study #4", due: "Tomorrow · 11:59 PM", course: "DMS 210" },
  { type: "Exam", title: "MRI Physics — Midterm", due: "Fri · May 22 · 10:00 AM", course: "MRI 305" },
  { type: "Reading", title: "Vascular Doppler Principles, Ch. 7", due: "Mon · May 25", course: "DMS 220" },
];

const courses = [
  { code: "DMS 210", title: "Abdominal & Small Parts Sonography", students: 24, progress: 68, accent: "from-teal/20 to-sage/40" },
  { code: "DMS 220", title: "Vascular Sonography", students: 19, progress: 42, accent: "from-sage/60 to-cream" },
  { code: "MRI 305", title: "MRI Physics & Instrumentation", students: 21, progress: 55, accent: "from-cream to-teal/30" },
  { code: "MRI 410", title: "Cross-Sectional Anatomy for MRI", students: 18, progress: 30, accent: "from-sage/40 to-teal/20" },
];

function Dashboard() {
  return (
    <div className="space-y-16">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-border/60 bg-card px-8 py-14 ring-soft md:px-14 md:py-20">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-accent/20 blur-3xl" />
        <div className="absolute -bottom-32 -left-20 h-80 w-80 rounded-full bg-sage/60 blur-3xl" />
        <div className="relative max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-3 py-1 text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Spring Semester · Week 9
          </div>
          <h1 className="mt-6 font-serif text-5xl leading-[1.05] md:text-7xl">
            Welcome back, <em className="italic text-accent">Dr. Inam</em>.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Your Ultrasound, Sonography and MRI students have three assignments due this week.
            Review submissions, publish a new study guide, or schedule the next practical exam.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/assignments" className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90">
              Review submissions <ArrowUpRight className="h-4 w-4" />
            </Link>
            <Link to="/study-guides" className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-5 py-2.5 text-sm font-medium hover:bg-secondary">
              Publish study guide
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid gap-4 md:grid-cols-4">
        {[
          { icon: GraduationCap, label: "Active students", value: "82", msg: "82 students enrolled across 4 programs this semester." },
          { icon: BookOpen, label: "Live courses", value: "4", msg: "DMS 210, DMS 220, MRI 305, MRI 410 are currently active." },
          { icon: ClipboardList, label: "To grade", value: "17", msg: "17 submissions awaiting your review." },
          { icon: Activity, label: "Avg. class score", value: "87%", msg: "Class average is up 3% from last semester." },
        ].map((s) => (
          <button
            key={s.label}
            onClick={() => toast.info(s.label, { description: s.msg })}
            className="rounded-2xl border border-border/60 bg-card p-5 text-left transition hover:ring-soft"
          >
            <s.icon className="h-5 w-5 text-accent" />
            <div className="mt-4 font-serif text-4xl">{s.value}</div>
            <div className="mt-1 text-xs uppercase tracking-[0.15em] text-muted-foreground">{s.label}</div>
          </button>
        ))}
      </section>

      {/* Two-column */}
      <section className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-end justify-between">
            <h2 className="font-serif text-3xl">Your courses</h2>
            <Link to="/courses" className="text-sm text-accent hover:underline">View all →</Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {courses.map((c) => (
              <Link key={c.code} to="/courses" className={`group relative overflow-hidden rounded-2xl border border-border/60 bg-gradient-to-br ${c.accent} p-6 transition hover:-translate-y-0.5 hover:ring-soft`}>
                <div className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">{c.code}</div>
                <h3 className="mt-2 font-serif text-2xl leading-tight">{c.title}</h3>
                <div className="mt-6 flex items-end justify-between">
                  <div className="text-xs text-muted-foreground">{c.students} students</div>
                  <div className="text-xs font-medium">{c.progress}%</div>
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-background/60">
                  <div className="h-full bg-primary" style={{ width: `${c.progress}%` }} />
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-4 font-serif text-3xl">Upcoming</h2>
          <div className="space-y-3">
            {upcoming.map((u) => (
              <div key={u.title} className="rounded-2xl border border-border/60 bg-card p-5">
                <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.15em] text-accent">
                  {u.type === "Exam" ? <Clock className="h-3 w-3" /> : <Calendar className="h-3 w-3" />}
                  {u.type} · {u.course}
                </div>
                <div className="mt-2 font-medium">{u.title}</div>
                <div className="mt-1 text-xs text-muted-foreground">{u.due}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
