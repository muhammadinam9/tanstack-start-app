import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Toaster } from "sonner";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-7xl text-foreground">404</h1>
        <p className="mt-2 text-sm text-muted-foreground">This page isn't in the syllabus.</p>
        <Link to="/" className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground hover:opacity-90">Back to dashboard</Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-2xl">Something went wrong</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <button onClick={() => { router.invalidate(); reset(); }} className="mt-6 rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground">Try again</button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Aquarius Institute · Ultrasound & MRI Learning Portal" },
      { name: "description", content: "Learning portal for the Ultrasound, Sonography and MRI Technologist programs at Aquarius Institute of Des Plaines, led by Dr. Tehmina Inam." },
      { property: "og:title", content: "Aquarius Institute Learning Portal" },
      { property: "og:description", content: "Homework, exams, study guides and grades for Ultrasound and MRI students." },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Work+Sans:wght@400;500;600&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

const NAV_LINKS = [
  { to: "/", label: "Dashboard" },
  { to: "/courses", label: "Courses" },
  { to: "/assignments", label: "Assignments" },
  { to: "/exams", label: "Exams" },
  { to: "/study-guides", label: "Study Guides" },
  { to: "/grades", label: "Grades" },
] as const;

function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3" onClick={() => setMobileOpen(false)}>
          <div className="grid h-9 w-9 place-items-center rounded-full bg-accent text-accent-foreground font-serif text-lg">A</div>
          <div className="leading-tight">
            <div className="font-serif text-lg">Aquarius Institute</div>
            <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Des Plaines · Learning Portal</div>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="rounded-full px-3 py-1.5 text-sm text-foreground/70 transition hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "rounded-full px-3 py-1.5 text-sm bg-secondary text-foreground" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-3">
          <div className="hidden text-right text-xs leading-tight md:block">
            <div className="font-medium">Dr. Tehmina Inam</div>
            <div className="text-muted-foreground">Dept. Head, Ultrasound</div>
          </div>
          <div className="grid h-9 w-9 place-items-center rounded-full bg-primary font-serif text-sm text-primary-foreground">TI</div>
          {/* Hamburger — mobile only */}
          <button
            className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card md:hidden"
            aria-label="Toggle menu"
            onClick={() => setMobileOpen((o) => !o)}
          >
            {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <nav className="border-t border-border/60 bg-background px-6 pb-6 pt-4 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="rounded-xl px-4 py-3 text-sm text-foreground/70 transition hover:bg-secondary hover:text-foreground"
                activeProps={{ className: "rounded-xl px-4 py-3 text-sm bg-secondary text-foreground font-medium" }}
                activeOptions={{ exact: l.to === "/" }}
                onClick={() => setMobileOpen(false)}
              >
                {l.label}
              </Link>
            ))}
          </div>
          <div className="mt-4 border-t border-border/60 pt-4 text-xs text-muted-foreground">
            Dr. Tehmina Inam · Dept. Head, Ultrasound
          </div>
        </nav>
      )}
    </header>
  );
}

function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-secondary/40">
      <div className="mx-auto grid max-w-7xl gap-8 px-6 py-12 md:grid-cols-3">
        <div>
          <div className="font-serif text-xl">Aquarius Institute</div>
          <p className="mt-2 max-w-xs text-sm text-muted-foreground">
            Educating the next generation of Ultrasound and MRI technologists in Des Plaines, Illinois.
          </p>
        </div>
        <div className="text-sm">
          <div className="mb-2 text-xs uppercase tracking-[0.18em] text-muted-foreground">Programs</div>
          <ul className="space-y-1">
            <li>Diagnostic Medical Sonography</li>
            <li>MRI Technologist</li>
            <li>Continuing Education</li>
          </ul>
        </div>
        <div className="text-sm">
          <div className="mb-2 text-xs uppercase tracking-[0.18em] text-muted-foreground">Contact</div>
          <p className="text-muted-foreground">Department of Ultrasound<br />Aquarius Institute, Des Plaines, IL<br />Head: Dr. Tehmina Inam</p>
        </div>
      </div>
      <div className="border-t border-border/60 py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Aquarius Institute of Des Plaines. All rights reserved.
      </div>
    </footer>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-background bg-grain">
        <SiteHeader />
        <main className="mx-auto max-w-7xl px-6 py-10">
          <Outlet />
        </main>
        <SiteFooter />
        <Toaster position="bottom-right" richColors />
      </div>
    </QueryClientProvider>
  );
}
