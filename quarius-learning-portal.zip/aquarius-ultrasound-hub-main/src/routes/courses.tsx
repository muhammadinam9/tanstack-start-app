import { createFileRoute } from "@tanstack/react-router";
import { Users, Clock, Award } from "lucide-react";

export const Route = createFileRoute("/courses")({
  head: () => ({
    meta: [
      { title: "Courses · Aquarius Institute" },
      { name: "description", content: "Ultrasound, Sonography and MRI Technologist courses taught by Dr. Tehmina Inam." },
    ],
  }),
  component: Courses,
});

const programs = [
  {
    name: "Diagnostic Medical Sonography",
    tagline: "Two-year associate program in ultrasound imaging.",
    courses: [
      { code: "DMS 110", title: "Introduction to Sonography", credits: 4, schedule: "Mon · Wed · 9:00 AM" },
      { code: "DMS 210", title: "Abdominal & Small Parts Sonography", credits: 5, schedule: "Tue · Thu · 10:30 AM" },
      { code: "DMS 220", title: "Vascular Sonography", credits: 4, schedule: "Mon · Wed · 1:00 PM" },
      { code: "DMS 320", title: "Obstetrics & Gynecology Sonography", credits: 5, schedule: "Tue · Thu · 2:00 PM" },
    ],
  },
  {
    name: "MRI Technologist Program",
    tagline: "Comprehensive training in magnetic resonance imaging.",
    courses: [
      { code: "MRI 205", title: "Patient Care & Safety in MRI", credits: 3, schedule: "Fri · 9:00 AM" },
      { code: "MRI 305", title: "MRI Physics & Instrumentation", credits: 5, schedule: "Mon · Wed · 11:00 AM" },
      { code: "MRI 410", title: "Cross-Sectional Anatomy for MRI", credits: 4, schedule: "Tue · Thu · 9:00 AM" },
      { code: "MRI 420", title: "Advanced MRI Procedures", credits: 4, schedule: "Tue · Thu · 1:00 PM" },
    ],
  },
];

function Courses() {
  return (
    <div className="space-y-16">
      <header className="max-w-3xl">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Department of Ultrasound</div>
        <h1 className="mt-3 font-serif text-5xl md:text-6xl">Courses & Programs</h1>
        <p className="mt-5 text-lg text-muted-foreground">
          Curriculum for the Diagnostic Medical Sonography and MRI Technologist tracks at Aquarius Institute of Des Plaines.
        </p>
      </header>

      {programs.map((p) => (
        <section key={p.name}>
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b border-border/60 pb-4">
            <div>
              <h2 className="font-serif text-3xl">{p.name}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{p.tagline}</p>
            </div>
            <div className="flex gap-6 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><Users className="h-3.5 w-3.5" /> 40+ students</span>
              <span className="inline-flex items-center gap-1.5"><Award className="h-3.5 w-3.5" /> ARRT prep</span>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {p.courses.map((c) => (
              <div key={c.code} className="group rounded-2xl border border-border/60 bg-card p-6 transition hover:ring-soft">
                <div className="flex items-start justify-between">
                  <div className="text-xs font-medium uppercase tracking-[0.18em] text-accent">{c.code}</div>
                  <div className="text-xs text-muted-foreground">{c.credits} credits</div>
                </div>
                <h3 className="mt-3 font-serif text-2xl leading-tight">{c.title}</h3>
                <div className="mt-5 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" /> {c.schedule}
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
