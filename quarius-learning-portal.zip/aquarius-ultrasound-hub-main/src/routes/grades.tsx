import { createFileRoute } from "@tanstack/react-router";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export const Route = createFileRoute("/grades")({
  head: () => ({
    meta: [
      { title: "Grades · Aquarius Institute" },
      { name: "description", content: "Class performance and individual grade tracking for ultrasound and MRI courses." },
    ],
  }),
  component: Grades,
});

const courseGrades = [
  { course: "DMS 210 · Abdominal Sonography", avg: 88, trend: "up", letter: "B+" },
  { course: "DMS 220 · Vascular Sonography", avg: 82, trend: "flat", letter: "B" },
  { course: "MRI 305 · MRI Physics", avg: 91, trend: "up", letter: "A-" },
  { course: "MRI 410 · Cross-Sectional Anatomy", avg: 78, trend: "down", letter: "C+" },
];

const recentScores = [
  { student: "Maria Gonzalez", item: "Case Study #3", course: "DMS 210", score: 94 },
  { student: "James Liu", item: "Lab Report: T1/T2", course: "MRI 305", score: 88 },
  { student: "Aisha Patel", item: "Doppler Quiz", course: "DMS 220", score: 76 },
  { student: "Brandon Reilly", item: "Anatomy Worksheet", course: "MRI 410", score: 82 },
  { student: "Sofia Martinez", item: "Probe Handling Essay", course: "DMS 110", score: 96 },
  { student: "Daniel Okafor", item: "Case Study #3", course: "DMS 210", score: 71 },
];

function Trend({ t }: { t: string }) {
  if (t === "up") return <TrendingUp className="h-4 w-4 text-accent" />;
  if (t === "down") return <TrendingDown className="h-4 w-4 text-destructive" />;
  return <Minus className="h-4 w-4 text-muted-foreground" />;
}

function Grades() {
  return (
    <div className="space-y-12">
      <header className="max-w-3xl">
        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Progress</div>
        <h1 className="mt-3 font-serif text-5xl md:text-6xl">Grades & Performance</h1>
        <p className="mt-4 text-muted-foreground">Track individual progress and identify students who may need additional support.</p>
      </header>

      <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {courseGrades.map((c) => (
          <div key={c.course} className="rounded-2xl border border-border/60 bg-card p-6">
            <div className="flex items-start justify-between">
              <div className="text-xs uppercase tracking-[0.15em] text-muted-foreground">{c.course.split(" · ")[0]}</div>
              <Trend t={c.trend} />
            </div>
            <div className="mt-5 flex items-baseline gap-2">
              <span className="font-serif text-5xl">{c.avg}</span>
              <span className="text-sm text-muted-foreground">%</span>
            </div>
            <div className="mt-1 text-sm text-muted-foreground">Class average · {c.letter}</div>
            <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-muted">
              <div className="h-full bg-accent" style={{ width: `${c.avg}%` }} />
            </div>
          </div>
        ))}
      </section>

      <section className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="overflow-hidden rounded-2xl border border-border/60 bg-card">
          <div className="border-b border-border/60 px-6 py-4">
            <h2 className="font-serif text-2xl">Recent submissions</h2>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-[0.12em] text-muted-foreground">
              <tr>
                <th className="px-6 py-3 text-left">Student</th>
                <th className="px-6 py-3 text-left">Item</th>
                <th className="px-6 py-3 text-left">Course</th>
                <th className="px-6 py-3 text-right">Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {recentScores.map((r, i) => (
                <tr key={i} className="hover:bg-secondary/30">
                  <td className="px-6 py-4 font-medium">{r.student}</td>
                  <td className="px-6 py-4 text-muted-foreground">{r.item}</td>
                  <td className="px-6 py-4 text-xs text-accent">{r.course}</td>
                  <td className="px-6 py-4 text-right">
                    <span className={`font-serif text-xl ${r.score >= 90 ? "text-accent" : r.score >= 75 ? "text-foreground" : "text-destructive"}`}>{r.score}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="rounded-2xl border border-border/60 bg-gradient-to-br from-sage/40 to-cream p-6">
          <h3 className="font-serif text-2xl">Grading scale</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {[
              ["A", "93–100"],
              ["A-", "90–92"],
              ["B+", "87–89"],
              ["B", "83–86"],
              ["B-", "80–82"],
              ["C+", "77–79"],
              ["C", "73–76"],
              ["F", "Below 70"],
            ].map(([l, r]) => (
              <li key={l} className="flex items-center justify-between border-b border-border/40 pb-1.5">
                <span className="font-serif text-lg">{l}</span>
                <span className="text-muted-foreground">{r}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
