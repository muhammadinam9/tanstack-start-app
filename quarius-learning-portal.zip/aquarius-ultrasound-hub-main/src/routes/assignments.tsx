import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Upload, FileText, CheckCircle2, AlertCircle, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/assignments")({
  head: () => ({
    meta: [
      { title: "Assignments · Aquarius Institute" },
      { name: "description", content: "Homework and clinical case studies for Ultrasound and MRI students." },
    ],
  }),
  component: Assignments,
});

const assignments = [
  { course: "DMS 210", title: "Abdominal Sonography — Case Study #4", due: "Tomorrow · 11:59 PM", status: "open", points: 50, submitted: 18, total: 24 },
  { course: "MRI 305", title: "Lab Report: T1 vs T2 Weighting", due: "Thu · May 21", status: "open", points: 40, submitted: 9, total: 21 },
  { course: "DMS 220", title: "Doppler Waveform Identification", due: "Mon · May 25", status: "open", points: 30, submitted: 4, total: 19 },
  { course: "MRI 410", title: "Cross-Sectional Anatomy Quiz Worksheet", due: "Wed · May 14", status: "closed", points: 25, submitted: 18, total: 18 },
  { course: "DMS 110", title: "Probe Handling Reflection Essay", due: "Mon · May 11", status: "closed", points: 20, submitted: 22, total: 24 },
];

function StatusBadge({ status }: { status: string }) {
  const open = status === "open";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wider ${open ? "bg-accent/15 text-accent" : "bg-muted text-muted-foreground"}`}>
      {open ? <AlertCircle className="h-3 w-3" /> : <CheckCircle2 className="h-3 w-3" />}
      {open ? "Open" : "Closed"}
    </span>
  );
}

type UploadedFile = { name: string; size: string };

const ACCEPTED = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "image/jpeg", "image/png"];
const ACCEPTED_EXT = ".pdf,.docx,.jpg,.jpeg,.png";

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function Assignments() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [dragging, setDragging] = useState(false);

  function handleFiles(incoming: FileList | null) {
    if (!incoming) return;
    const valid: UploadedFile[] = [];
    for (const f of Array.from(incoming)) {
      if (f.size > 50 * 1024 * 1024) {
        toast.error(`${f.name} exceeds 50 MB limit`);
        continue;
      }
      valid.push({ name: f.name, size: formatSize(f.size) });
    }
    if (valid.length) {
      setFiles((prev) => [...prev, ...valid]);
      toast.success(`${valid.length} file${valid.length > 1 ? "s" : ""} added`);
    }
  }

  function removeFile(name: string) {
    setFiles((prev) => prev.filter((f) => f.name !== name));
  }

  function handleSubmit() {
    if (!files.length) {
      toast.error("No files selected", { description: "Please attach at least one file before submitting." });
      return;
    }
    toast.success("Submission received!", { description: `${files.length} file${files.length > 1 ? "s" : ""} submitted successfully.` });
    setFiles([]);
  }

  return (
    <div className="space-y-12">
      <header className="flex flex-wrap items-end justify-between gap-6">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Coursework</div>
          <h1 className="mt-3 font-serif text-5xl md:text-6xl">Assignments</h1>
          <p className="mt-4 text-muted-foreground">Submit homework, case studies and clinical reports. Late work is accepted at instructor discretion.</p>
        </div>
        <button
          onClick={() => toast.info("Assignment editor coming soon", { description: "This feature is in development." })}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90 transition"
        >
          <Upload className="h-4 w-4" /> New assignment
        </button>
      </header>

      {/* Table */}
      <div className="overflow-x-auto overflow-hidden rounded-2xl border border-border/60 bg-card">
        <table className="w-full text-sm">
          <thead className="bg-secondary/60 text-xs uppercase tracking-[0.12em] text-muted-foreground">
            <tr>
              <th className="px-6 py-3 text-left">Course</th>
              <th className="px-6 py-3 text-left">Title</th>
              <th className="px-6 py-3 text-left">Due</th>
              <th className="px-6 py-3 text-left">Status</th>
              <th className="px-6 py-3 text-right">Submissions</th>
              <th className="px-6 py-3 text-right">Points</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {assignments.map((a) => (
              <tr
                key={a.title}
                className="transition hover:bg-secondary/30 cursor-pointer"
                onClick={() => toast.info(a.title, { description: `${a.course} · Due ${a.due} · ${a.points} pts` })}
              >
                <td className="px-6 py-4 text-xs font-medium text-accent">{a.course}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{a.title}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-muted-foreground">{a.due}</td>
                <td className="px-6 py-4"><StatusBadge status={a.status} /></td>
                <td className="px-6 py-4 text-right">
                  <span className="font-medium">{a.submitted}</span>
                  <span className="text-muted-foreground"> / {a.total}</span>
                </td>
                <td className="px-6 py-4 text-right text-muted-foreground">{a.points} pts</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Upload zone */}
      <section className="rounded-3xl border border-border/60 bg-gradient-to-br from-sage/40 to-cream p-8 md:p-12">
        <div className="grid gap-8 md:grid-cols-[2fr_1fr] md:items-start">
          <div>
            <h2 className="font-serif text-3xl md:text-4xl">Submit your work</h2>
            <p className="mt-3 text-muted-foreground">Drag and drop case study PDFs, sonogram images, or lab reports. Files up to 50 MB are supported.</p>

            {/* File list */}
            {files.length > 0 && (
              <ul className="mt-6 space-y-2">
                {files.map((f) => (
                  <li key={f.name} className="flex items-center justify-between rounded-xl border border-border/60 bg-background/70 px-4 py-2.5 text-sm">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="h-4 w-4 shrink-0 text-accent" />
                      <span className="truncate font-medium">{f.name}</span>
                      <span className="shrink-0 text-xs text-muted-foreground">{f.size}</span>
                    </div>
                    <button onClick={() => removeFile(f.name)} className="ml-3 shrink-0 text-muted-foreground hover:text-destructive transition">
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}

            {files.length > 0 && (
              <button
                onClick={handleSubmit}
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition"
              >
                Submit {files.length} file{files.length > 1 ? "s" : ""}
              </button>
            )}
          </div>

          {/* Drop zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
            onClick={() => inputRef.current?.click()}
            className={`grid cursor-pointer place-items-center rounded-2xl border-2 border-dashed p-10 text-center transition ${dragging ? "border-accent bg-accent/10" : "border-accent/40 bg-background/60 hover:bg-background"}`}
          >
            <Upload className={`h-6 w-6 ${dragging ? "text-accent" : "text-accent"}`} />
            <div className="mt-3 text-sm font-medium">{dragging ? "Drop to add" : "Click or drop files here"}</div>
            <div className="mt-1 text-xs text-muted-foreground">PDF, DOCX, JPG, PNG · Max 50 MB</div>
            <input
              ref={inputRef}
              type="file"
              multiple
              accept={ACCEPTED_EXT}
              className="sr-only"
              onChange={(e) => handleFiles(e.target.files)}
            />
          </div>
        </div>
      </section>
    </div>
  );
}
