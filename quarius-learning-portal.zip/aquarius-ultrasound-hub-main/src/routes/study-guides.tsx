import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Download, BookMarked, Video, FileText, Headphones } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/study-guides")({
  head: () => ({
    meta: [
      { title: "Study Guides · Aquarius Institute" },
      { name: "description", content: "Reading lists, lecture notes, anatomy atlases and video lessons for ultrasound and MRI students." },
    ],
  }),
  component: StudyGuides,
});

const guides = [
  { icon: FileText, type: "PDF Guide", tag: "Ultrasound", title: "Abdominal Sonography Protocols", course: "DMS 210", pages: 42, color: "bg-accent/10 text-accent" },
  { icon: BookMarked, type: "Atlas", tag: "Anatomy", title: "Cross-Sectional Brain Anatomy", course: "MRI 410", pages: 88, color: "bg-sage/60 text-foreground" },
  { icon: Video, type: "Video Lesson", tag: "Ultrasound", title: "Doppler Waveform Interpretation", course: "DMS 220", pages: 24, color: "bg-primary/10 text-primary" },
  { icon: FileText, type: "Reference", tag: "ARRT Prep", title: "ARRT Exam Content Outline (2025)", course: "All programs", pages: 18, color: "bg-accent/10 text-accent" },
  { icon: Headphones, type: "Audio", tag: "MRI", title: "MRI Safety Walkthrough", course: "MRI 205", pages: 35, color: "bg-sage/60 text-foreground" },
  { icon: BookMarked, type: "Workbook", tag: "Ultrasound", title: "OB/GYN Sonography Practice Cases", course: "DMS 320", pages: 64, color: "bg-primary/10 text-primary" },
  { icon: FileText, type: "PDF Guide", tag: "Physics", title: "Ultrasound Physics — Wave Mechanics", course: "DMS 110", pages: 29, color: "bg-accent/10 text-accent" },
  { icon: Video, type: "Video Lesson", tag: "MRI", title: "T1 vs T2 Weighting Explained", course: "MRI 305", pages: 18, color: "bg-primary/10 text-primary" },
  { icon: BookMarked, type: "Atlas", tag: "Anatomy", title: "Abdominal Organ Anatomy Atlas", course: "DMS 210", pages: 55, color: "bg-sage/60 text-foreground" },
];

const FILTERS = ["All", "Ultrasound", "MRI", "Anatomy", "Physics", "ARRT Prep"] as const;
type Filter = (typeof FILTERS)[number];

function StudyGuides() {
  const [active, setActive] = useState<Filter>("All");

  const filtered = active === "All" ? guides : guides.filter((g) => g.tag === active);

  return (
    <div className="space-y-12">
      <header className="grid gap-8 md:grid-cols-[2fr_1fr] md:items-end">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Library</div>
          <h1 className="mt-3 font-serif text-5xl md:text-6xl">Study Guides</h1>
          <p className="mt-4 text-muted-foreground">
            Curated learning materials — protocols, atlases, video lessons and ARRT exam prep. Updated weekly by Dr. Tehmina Inam and faculty.
          </p>
        </div>
        <div className="rounded-2xl border border-border/60 bg-card p-6">
          <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Featured this week</div>
          <h3 className="mt-2 font-serif text-2xl leading-tight">Liver Pathology Pictorial Review</h3>
          <p className="mt-2 text-sm text-muted-foreground">A 36-image case set covering hepatic lesions on ultrasound.</p>
          <button
            onClick={() => toast.success("Opening guide…", { description: "Liver Pathology Pictorial Review" })}
            className="mt-4 inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-xs font-medium text-accent-foreground hover:opacity-90 transition"
          >
            <Download className="h-3.5 w-3.5" /> Open guide
          </button>
        </div>
      </header>

      <section>
        <div className="mb-6 flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`rounded-full border px-4 py-1.5 text-xs font-medium transition ${
                active === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-foreground hover:bg-secondary"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-border/60 bg-card py-20 text-center text-muted-foreground">
            No guides in this category yet.
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((g) => (
              <article
                key={g.title}
                className="group flex h-full flex-col rounded-2xl border border-border/60 bg-card p-6 transition hover:-translate-y-0.5 hover:ring-soft"
              >
                <div className={`inline-grid h-10 w-10 place-items-center rounded-xl ${g.color}`}>
                  <g.icon className="h-5 w-5" />
                </div>
                <div className="mt-5 text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
                  {g.type} · {g.course}
                </div>
                <h3 className="mt-2 flex-1 font-serif text-2xl leading-tight">{g.title}</h3>
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{g.pages} pages</span>
                  <button
                    onClick={() => toast.success("Download started", { description: g.title })}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-accent hover:underline"
                  >
                    <Download className="h-3.5 w-3.5" /> Download
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
